// const slider = document.querySelectorAll('.slide');
// var counter = 0;
// slider.forEach(
//     (slide, index)=> {
//         slide.style.top = `${index*100}%`
//     }
// )
// const SlideImage = () => {
//     slider.forEach(
//         (slide) => {
//             slide.style.transform = `translateY(-${counter*100}%)`
//         }
//     )
//     setTimeout(SlideImage , 1000);
// }
// const goPrev = () => {
//     counter--
//     SlideImage();

// }
// const goNext = () => {
//     counter++
//     SlideImage();
// }
//Creating Slider using javascript

// const slider = document.querySelectorAll('.slide');
// counter = 0;
// slider.forEach(
//     (slide, index) => {
//         slide.style.left = `${index*100}%`
//     }
// )
// const SlideImage = () => {
//     slider.forEach(
//         (slide) => {
//             slide.style.transform = `translateX(-${counter*100}%)`
//         }
//     )
  
// }
// const goPrev = () => {
//     counter++
   
//     SlideImage();
// }
// const goNext = () => {
//     counter-- 
   
//     SlideImage();
// }
const slider = document.querySelectorAll('.slide');
// console.log(slider);
var counter =0;
slider.forEach (
    (slide,index) => {
        slide.style.left = `${index*100}%`;
    }
)
const slideImage =() => {
    slider.forEach(
    (slide) => {
        slide.style.transform = `translateX(-${counter*100}%)`
    }
    )
}
// const SlideImage = () => {
    //     slider.forEach(
    //         (slide) => {
    //             slide.style.transform = `translateX(-${counter*100}%)`
    //         }
    //     )
const goPrev = () => {
         
        counter--   
        slideImage();    
   
 
   
}
const goNext = () => {
    
        counter++
        slideImage();
 
    
    
    
}
