const image = document.querySelectorAll('.item_img img');

const modal = document.querySelector('.modal');
const close_btn = document.querySelector('.close_btn');
const modal_img = document.querySelector('.modal_img');
const modal_text = document.querySelector('.modal_text');



image.forEach(
    (thisimage) => {
        thisimage.addEventListener('click', function() {
            modal_img.src = thisimage.src;
            modal_text.innerText = thisimage.alt;
            modal.classList.add('active');
            close_btn.addEventListener('click', function(){
                modal.classList.remove('active');
            })            
        } )
    }
)
