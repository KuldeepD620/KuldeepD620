var image_box, modal, close_btn, modal_img, modal_text;
image_box = document.querySelectorAll('.image_box img');
modal = document.querySelector('.modal');
modal_img = document.querySelector('.modal_img');
console.log(modal_img);
close_btn = document.querySelector('.close_btn');
modal_text = document.querySelector('.modal_text');

image_box.forEach(
    (image) => {
        image.addEventListener('click', function() {
            modal_img.src = image.src;
            modal_text.innerHTML = image.alt;  
            modal.classList.add('appear'); 
            close_btn.addEventListener('click', function() {
                modal.classList.remove('appear');                
            })     
        })

    }
)

