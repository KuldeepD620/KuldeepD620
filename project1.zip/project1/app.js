
/* Modal Box Coding Starts here */
const image_box = document.querySelectorAll('.item_img img');
const close_btn = document.querySelector('.close_btn');
const modal_img = document.querySelector('.modal_img');
const modal_text = document.querySelector('.modal_text');
const modal = document.querySelector('.modal_box');
/* Funtion to display modal box on display after clicking on any image*/

image_box.forEach(
    (image) => {
        image.addEventListener('click', function() {
            modal_img.src = image.src;
            modal_text.innerHTML = image.alt;
            modal.classList.add('appear')
            close_btn.addEventListener('click', function() {
             modal.classList.remove('appear');
                
            })
        })
    }
)

/* Modal Box Coding Ends here */
/* Filter Gallery Coding Starts here*/
 const filter_menu = document.querySelectorAll('.nav-link');
 const store_item = document.querySelectorAll('.item_img');
//   Check Filter menu was clicked
filter_menu.forEach(
    (tab) => {
        tab.addEventListener('click', (e)=> {
            e.preventDefault();
        const filter = e.target.dataset.filter;
// Coding To Arrange Images accoding to filter 
        store_item.forEach(
            (image) => {
                if(filter ==='all'){
                    image.style.display = 'block';
                }
                else {
                    if(image.classList.contains(filter)){
                        image.style.display = 'block';
                    }
                    else{
                        image.style.display ='none';
                    }
                }
            }
        )

        })    }
)
/*Filter Gallery Coding Ends Here */
// Testimonial Coding Starts Here
const slides = document.getElementById('slide_box')
const buttons = document.getElementsByClassName('buttons');
buttons[0].onclick = function() {
    slides.style.transform =  "translateX(0px)"
    for(let i =0; i<3;i++){
        buttons[i].classList.remove('active')
    }this.classList.add('active');
  
}
buttons[1].onclick = function () {
    slides.style.transform = "translateX(-400px)"
    for(let i =0; i<3;i++){
        buttons[i].classList.remove('active')
    }this.classList.add('active');
}
buttons[2].onclick = function() {
    slides.style.transform = "translateX(-800px)"
    for(let i =0; i<3;i++){
        buttons[i].classList.remove('active')
    }this.classList.add('active');
}


// Testimonial Coding Ends here


